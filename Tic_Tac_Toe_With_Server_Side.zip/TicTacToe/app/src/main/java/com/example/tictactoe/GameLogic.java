package com.example.tictactoe;

import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class GameLogic {
    private int[][] gameBoard;

    //1st element --> row , 2nd element --> col, 3nd element --> line type
    private int[] winType= {-1,-1,-1};
    public static int cycleTime=0;
    private int player = 1;

    private String[] players;

    private Button playAgainBTN;
    private Button  homeBTN;
    private TextView playerTurn;



    private static ExecutorService threadPool = Executors.newFixedThreadPool(3);



    public GameLogic(){
        gameBoard = new int[3][3];
        for (int r = 0; r < 3; r++) {
            for (int c = 0; c < 3; c++) {
                gameBoard[r][c]=0;
            }
        }
    }

    public boolean updateGameBoard(int row, int col){
        Future<Boolean> futureResult = threadPool.submit(
                ()->{
                    boolean isEmpty=false;
                    try {
                        Socket socket = new Socket("10.0.2.2", 8010);
                        ObjectOutputStream toServer = new ObjectOutputStream(socket.getOutputStream());
                        ObjectInputStream fromServer = new ObjectInputStream(socket.getInputStream());

                        System.out.println("client: Created Socket");

                        //send "matrix" command then write 2d array to socket
                        toServer.writeObject("matrix");
                        toServer.writeObject(gameBoard);

                        //send command then write an index to socket
                        toServer.writeObject("targetIsEmpty");
                        toServer.writeObject(row);
                        toServer.writeObject(col);

                        // get neighboring indices as list
                        isEmpty=((boolean) fromServer.readObject());
                        System.out.println("Yayy im empty!");

                        toServer.writeObject("stop");
                        System.out.println("client: Close all streams");
                        fromServer.close();
                        toServer.close();
                        socket.close();

                        System.out.println("client: Closed operational socket");

                    } catch (IOException | ClassNotFoundException e) {
                        e.printStackTrace();
                    }


                    return isEmpty;
                }
        );
        try{
            Boolean res = futureResult.get();
            if(res){
                System.out.println("Cycle Count " + cycleTime);
                gameBoard[row-1][col-1]=player;
                if(player==1){
                    playerTurn.setText(players[1]+"'s Turn");
                }else{
                    playerTurn.setText(players[0]+"'s Turn");
                }
                return true;
            }else{
                return false;
            }
        }catch (InterruptedException | ExecutionException e){
            e.printStackTrace();
        }
      return false;
    }

    public boolean winnerCheck(){
        System.out.println("-------------  "+winType[0]+"  -------------");
        System.out.println("-------------  "+winType[1]+"  -------------");
        System.out.println("-------------  "+winType[2]+"  -------------");

        Future<Boolean> futureResult = threadPool.submit(
                ()->{
                    boolean gameWinner=false;
                    try {
                        Socket socket = new Socket("10.0.2.2", 8010);
                        ObjectOutputStream toServer = new ObjectOutputStream(socket.getOutputStream());
                        ObjectInputStream fromServer = new ObjectInputStream(socket.getInputStream());

                        System.out.println("client: Created Socket");

                        //send "matrix" command then write 2d array to socket
                        toServer.writeObject("matrix");
                        toServer.writeObject(gameBoard);

                        //send command then write an index to socket
                        toServer.writeObject("gameWinning");

                        // get neighboring indices as list
                        gameWinner=((boolean) fromServer.readObject());
                        System.out.println("Yayy im winner here!");

                        toServer.writeObject("stop");
                        System.out.println("client: Close all streams");
                        fromServer.close();
                        toServer.close();
                        socket.close();

                        System.out.println("client: Closed operational socket");

                    } catch (IOException | ClassNotFoundException e) {
                        e.printStackTrace();
                    }
                    return gameWinner;
                }
        );
        try{
            Boolean res = futureResult.get();
            if(res) {
                Future<int[]> futureResult_winType = threadPool.submit(
                        ()->{
                            int[] winningType=null;
                            try {
                                Socket socket = new Socket("10.0.2.2", 8010);
                                ObjectOutputStream toServer = new ObjectOutputStream(socket.getOutputStream());
                                ObjectInputStream fromServer = new ObjectInputStream(socket.getInputStream());

                                System.out.println("client: Created Socket");

                                //send command then write an index to socket
                                toServer.writeObject("findWinType");

                                // get neighboring indices as list
                                winningType=((int[]) fromServer.readObject());
                                System.out.println("Looking for win type");

                                toServer.writeObject("stop");
                                System.out.println("client: Close all streams");
                                fromServer.close();
                                toServer.close();
                                socket.close();

                                System.out.println("client: Closed operational socket");

                            } catch (IOException | ClassNotFoundException e) {
                                e.printStackTrace();
                            }
                            return winningType;
                        }
                );
                try{
                    int[] winningType = futureResult_winType.get();
                    winType=winningType;

                }catch (InterruptedException | ExecutionException e){
                    e.printStackTrace();
                }

                playAgainBTN.setVisibility(View.VISIBLE);
                homeBTN.setVisibility(View.VISIBLE);
                playerTurn.setText((players[player-1])+" Won!!!!!");
                cycleTime++;
                return true;
            }else{
                Future<Integer> futureResult_tie = threadPool.submit(
                        ()->{
                            int fullBoard=0;
                            try {
                                Socket socket = new Socket("10.0.2.2", 8010);
                                ObjectOutputStream toServer = new ObjectOutputStream(socket.getOutputStream());
                                ObjectInputStream fromServer = new ObjectInputStream(socket.getInputStream());

                                System.out.println("client: Created Socket");

                                //send "matrix" command then write 2d array to socket
                                toServer.writeObject("matrix");
                                toServer.writeObject(gameBoard);

                                //send command then write an index to socket
                                toServer.writeObject("gameTie");

                                // get neighboring indices as list
                                fullBoard=((int) fromServer.readObject());
                                System.out.println("Ohh seems like Tied Game!!");

                                toServer.writeObject("stop");
                                System.out.println("client: Close all streams");
                                fromServer.close();
                                toServer.close();
                                socket.close();

                                System.out.println("client: Closed operational socket");

                            } catch (IOException | ClassNotFoundException e) {
                                e.printStackTrace();
                            }
                            return fullBoard;
                        }
                );
                try{
                    int boardIsFull = futureResult_tie.get();
                    if(boardIsFull==9){
                        playAgainBTN.setVisibility(View.VISIBLE);
                        homeBTN.setVisibility(View.VISIBLE);
                        playerTurn.setText(" Tie Game!!!!!!");
                        return true;
                    }
                }catch (InterruptedException | ExecutionException e){
                    e.printStackTrace();
                }
            }
        }catch (InterruptedException | ExecutionException e){
            e.printStackTrace();
        }
        return false;
    }

    public void resetGame(){
        for (int r = 0; r < 3; r++) {
            for (int c = 0; c < 3; c++) {
                gameBoard[r][c]=0;
            }
        }

        int[] reloadWinType={-1,-1,-1};
        winType=reloadWinType;
        System.out.println("-----tt--------  "+winType[0]+"  -------tt------");
        System.out.println("-----tt--------  "+winType[1]+"  --------tt-----");
        System.out.println("------tt-------  "+winType[2]+"  --------tt-----");

        player=1;
        playAgainBTN.setVisibility(View.GONE);
        homeBTN.setVisibility(View.GONE);

        playerTurn.setText(players[0]+"'s Turn");
    }

    public void setPlayAgainBTN(Button playAgainBTN) {
        this.playAgainBTN = playAgainBTN;
    }

    public void setHomeBTN(Button homeBTN) {
        this.homeBTN = homeBTN;
        int[] reloadWinType={-1,-1,-1};
        winType=reloadWinType;

    }

    public void setPlayerTurn(TextView playerTurn) {
        this.playerTurn = playerTurn;
    }

    public void setPlayers(String[] players) {
        this.players = players;
    }

    public int[][] getGameBoard() {
        return gameBoard;
    }

    public int getPlayer() {
        return player;
    }

    public void setPlayer(int player) {
        this.player = player;
    }

    public int[] getWinType() {
        return winType;
    }
}
