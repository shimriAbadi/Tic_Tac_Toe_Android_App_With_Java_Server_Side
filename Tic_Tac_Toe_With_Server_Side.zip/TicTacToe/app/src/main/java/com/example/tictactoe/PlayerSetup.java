package com.example.tictactoe;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class PlayerSetup extends AppCompatActivity {

    private EditText player1,player2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.player_setup);

        player1 = findViewById(R.id.player1Name);
        player2 = findViewById(R.id.player2Name);
    }

    public void submitButtonClick(View view) {
        String player1Name = player1.getText().toString();
        String player2Name = player2.getText().toString();
        if(namesNotEmpty(player1Name,player2Name)){
            Intent intent = new Intent(this,GameDisplay.class);
            intent.putExtra("PLAYERS-NAMES",new String[] {player1Name,player2Name});
            startActivity(intent);
        }else{
            Toast.makeText(this,"Players names invalid!-> Try Again!",Toast.LENGTH_LONG).show();
        }
    }

    private boolean namesNotEmpty(String player1, String player2){
        if(player1.length()==0||player2.length()==0){
            return false;
        }else {
            return true;
        }
    }
}